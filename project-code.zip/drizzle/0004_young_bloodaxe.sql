ALTER TABLE `tweets` ADD `authorLocation` text;--> statement-breakpoint
ALTER TABLE `tweets` ADD `authorWebsite` text;--> statement-breakpoint
ALTER TABLE `tweets` ADD `authorJoinDate` text;
# Prompt برای Import در اکانت جدید

این prompt را کپی کنید و در اکانت جدید Manus به صورت کامل paste کنید.

---

## 📋 Prompt (کپی کن و paste کن)

```
من یک پروژه AI Twitter Monitor دارم که می‌خوام به این اکانت منتقل کنم. 

تمام کدها، تنظیمات، و دیتابیس رو دارم و می‌خوام دقیقاً همون پروژه رو اینجا بسازی بدون اینکه چیزی رو خودت تغییر بدی یا اضافه کنی.

**مهم: فقط کدهایی که بهت میدم رو استفاده کن. هیچ چیزی رو خودت نساز یا تغییر نده.**

## مرحله ۱: ساخت پروژه

یک پروژه جدید با این مشخصات بساز:

- نام پروژه: `ai-twitter-monitor-new`
- Template: `web-db-user` (React + tRPC + Database + Auth)
- Features: server, db, user

## مرحله ۲: آپلود کدها

الان تمام فایل‌های پروژه رو بهت می‌فرستم. این فایل‌ها رو دقیقاً همون‌طور که هستن در پروژه جدید قرار بده:

[در اینجا من فایل‌ها رو آپلود می‌کنم]

**نکته مهم:** اگر فایلی با نام مشابه وجود داشت، اون رو با فایل جدید replace کن. هیچ چیزی رو خودت اضافه یا تغییر نده.

## مرحله ۳: نصب Dependencies

```bash
pnpm install
```

## مرحله ۴: Setup دیتابیس

ابتدا schema رو push کن:

```bash
pnpm db:push
```

بعد دیتابیس رو import کن. من یک فایل JSON بهت میدم که باید import کنی:

```bash
npx tsx import-database.mjs database-backup-2025-11-11T16-47-47-877Z.json
```

## مرحله ۵: راه‌اندازی

سرور رو اجرا کن:

```bash
pnpm dev
```

## مرحله ۶: تنظیمات

بعد از راه‌اندازی، این تنظیمات رو در Settings وارد کن:

[در اینجا من تنظیمات رو بهت میدم]

## مرحله ۷: تست

تست کن که همه چیز کار می‌کنه:

1. Dashboard باز بشه
2. توییت‌ها نمایش داده بشن
3. Fetch کار کنه
4. Telegram bot پاسخ بده

اگر همه چیز درست بود، بهم بگو تا ادامه بدیم.
```

---

## 🗂️ فایل‌هایی که باید آپلود کنی

بعد از paste کردن prompt بالا، این فایل‌ها رو آپلود کن:

### فایل ۱: تمام کدها (ZIP)

از Management UI → Code → Download All Files

یا از اینجا:

```bash
cd /home/ubuntu/ai-twitter-monitor-new
zip -r project-code.zip . -x "node_modules/*" -x ".git/*" -x "*.log" -x "database-backup-*.json"
```

### فایل ۲: دیتابیس (JSON)

```
database-backup-2025-11-11T16-47-47-877Z.json
```

### فایل ۳: تنظیمات (JSON)

یک فایل `settings.json` بساز با این محتوا:

```json
{
  "apifyToken": "از Settings کپی کن",
  "telegramBotToken": "از Settings کپی کن",
  "telegramChatId": "از Settings کپی کن",
  "telegramOwnerId": "از Settings کپی کن",
  "openRouterApiKey": "از Settings کپی کن",
  "aiModel": "openai/gpt-4o",
  "aiRewritePrompt": "از Settings کپی کن",
  "temperature": "0.7",
  "maxTokens": "500",
  "topP": "0.9",
  "telegramTemplate": "از Settings کپی کن",
  "includeStats": true,
  "includeLink": true,
  "includeAuthor": true,
  "includeMedia": true,
  "includeDate": false,
  "keywords": "از Settings کپی کن",
  "scheduleTime": "از Settings کپی کن",
  "timezone": "از Settings کپی کن",
  "maxItemsPerRun": "200",
  "ownerEmails": "از Settings کپی کن"
}
```

---

## 📝 نکات مهم

1. **هیچ چیزی رو خودت نساز** - فقط فایل‌هایی که بهت میدم رو استفاده کن

2. **Replace کن نه Merge** - اگر فایلی وجود داشت، کاملاً replace کن

3. **تنظیمات رو دقیق کپی کن** - حتی یک کاراکتر هم اشتباه نباشه

4. **بعد از import دیتابیس، چک کن** که تعداد رکوردها درسته:
   ```sql
   SELECT COUNT(*) FROM users;      -- باید 3 باشد
   SELECT COUNT(*) FROM tweets;     -- باید 149 باشد
   SELECT COUNT(*) FROM settings;   -- باید 1 باشد
   ```

5. **Telegram bot رو setup کن** - بعد از همه چیز، به Settings برو و "Setup Telegram Mini App" رو کلیک کن

---

## 🚨 اگر مشکلی پیش اومد

اگر در هر مرحله‌ای خطا دادی، بهم بگو تا کمکت کنم. خطا رو کامل کپی کن و بفرست.

---

## ✅ Checklist نهایی

بعد از اتمام، این موارد رو چک کن:

- [ ] تمام فایل‌ها آپلود شدن
- [ ] `pnpm install` بدون خطا اجرا شد
- [ ] `pnpm db:push` بدون خطا اجرا شد
- [ ] دیتابیس import شد
- [ ] تعداد رکوردها درسته
- [ ] تنظیمات وارد شدن
- [ ] سرور اجرا میشه
- [ ] Dashboard باز میشه
- [ ] توییت‌ها نمایش داده میشن
- [ ] Telegram bot پاسخ میده

اگر همه ✅ بود، پروژه با موفقیت منتقل شده! 🎉

# راهنمای کامل انتقال پروژه AI Twitter Monitor به اکانت Manus جدید

**نویسنده:** Manus AI  
**تاریخ:** 11 نوامبر 2025  
**نسخه:** 1.0

---

## خلاصه اجرایی

این راهنما یک فرآیند جامع برای انتقال کامل پروژه **AI Twitter Monitor** از یک اکانت Manus به اکانت دیگر ارائه می‌دهد. این فرآیند تضمین می‌کند که هیچ داده‌ای از دست نرود و پروژه در اکانت جدید دقیقاً مانند اکانت قبلی کار کند.

---

## اجزای قابل انتقال

پروژه شامل اجزای زیر است که باید منتقل شوند:

### کدهای منبع (Source Code)

تمام فایل‌های پروژه شامل کدهای frontend (React)، backend (Express + tRPC)، و تنظیمات Drizzle ORM در این بخش قرار دارند. این کدها شامل منطق برنامه، رابط کاربری، و تعریف schema دیتابیس هستند.

### دیتابیس (Database)

پروژه از MySQL/TiDB استفاده می‌کند و شامل جداول زیر است:

| نام جدول | توضیحات | اهمیت |
|----------|---------|-------|
| `users` | اطلاعات کاربران و authentication | بحرانی |
| `settings` | تنظیمات عمومی پروژه (API keys, tokens, prompts) | بحرانی |
| `fetchSettings` | تنظیمات fetch (keywords, schedule, timezone) | بحرانی |
| `tweets` | توییت‌های fetch شده از Twitter/X | مهم |
| `bookmarks` | توییت‌های bookmark شده توسط کاربر | مهم |
| `savedTweets` | توییت‌های ذخیره شده | مهم |
| `scheduledPosts` | پست‌های زمان‌بندی شده برای ارسال | مهم |
| `runs` | تاریخچه اجراهای fetch | متوسط |
| `ignoredTweets` | توییت‌های ignore شده | متوسط |
| `sentPosts` | پست‌های ارسال شده به تلگرام | متوسط |
| `execution_locks` | قفل‌های اجرایی برای جلوگیری از اجرای همزمان | پایین |

### متغیرهای محیطی (Environment Variables)

متغیرهای محیطی که توسط سیستم Manus به صورت خودکار تزریق می‌شوند:

**متغیرهای سیستمی (تزریق خودکار):**
- `DATABASE_URL` - آدرس اتصال به دیتابیس
- `JWT_SECRET` - کلید رمزنگاری session
- `VITE_APP_ID` - شناسه برنامه Manus OAuth
- `OAUTH_SERVER_URL` - آدرس سرور OAuth
- `VITE_OAUTH_PORTAL_URL` - آدرس پورتال login
- `OWNER_OPEN_ID` - شناسه مالک پروژه
- `OWNER_NAME` - نام مالک پروژه
- `VITE_APP_TITLE` - عنوان برنامه
- `VITE_APP_LOGO` - لوگوی برنامه
- `BUILT_IN_FORGE_API_URL` - آدرس API های داخلی Manus
- `BUILT_IN_FORGE_API_KEY` - کلید API سمت سرور
- `VITE_FRONTEND_FORGE_API_KEY` - کلید API سمت frontend
- `VITE_FRONTEND_FORGE_API_URL` - آدرس API سمت frontend
- `GOOGLE_CLIENT_ID` - شناسه OAuth گوگل
- `GOOGLE_CLIENT_SECRET` - کلید OAuth گوگل

**متغیرهای کاربر (باید دستی تنظیم شوند):**
هیچ متغیر محیطی اضافی توسط کاربر تعریف نشده است. تمام تنظیمات در جدول `settings` دیتابیس ذخیره می‌شوند.

### تنظیمات برنامه (Application Settings)

تنظیمات برنامه در جدول `settings` ذخیره می‌شوند و شامل موارد زیر هستند:

| فیلد | توضیحات | نوع |
|------|---------|-----|
| `apifyToken` | توکن Apify برای fetch کردن توییت‌ها | API Key |
| `telegramBotToken` | توکن ربات تلگرام | API Key |
| `telegramChatId` | شناسه چت تلگرام | ID |
| `telegramOwnerId` | شناسه مالک در تلگرام | ID |
| `openRouterApiKey` | کلید API OpenRouter برای AI rewrite | API Key |
| `aiModel` | مدل AI (مثلاً `openai/gpt-4o`) | String |
| `aiRewritePrompt` | پرامپت AI برای rewrite کردن توییت‌ها | Text |
| `temperature` | پارامتر temperature برای AI | Number |
| `maxTokens` | حداکثر تعداد توکن‌های AI | Number |
| `topP` | پارامتر top_p برای AI | Number |
| `telegramTemplate` | قالب پیام تلگرام | Text |
| `includeStats` | نمایش آمار در پیام تلگرام | Boolean |
| `includeLink` | نمایش لینک در پیام تلگرام | Boolean |
| `includeAuthor` | نمایش نویسنده در پیام تلگرام | Boolean |
| `includeMedia` | نمایش media در پیام تلگرام | Boolean |
| `includeDate` | نمایش تاریخ در پیام تلگرام | Boolean |
| `keywords` | کلمات کلیدی برای جستجو | Text |
| `scheduleTime` | زمان اجرای خودکار | Time |
| `timezone` | منطقه زمانی | String |
| `maxItemsPerRun` | حداکثر تعداد توییت در هر اجرا | Number |
| `ownerEmails` | ایمیل‌های مالک | Text |

### Checkpoints

Checkpoints تاریخچه نسخه‌های پروژه را نگه می‌دارند. در صورت نیاز به بازگشت به نسخه قبلی، می‌توان از checkpoints استفاده کرد.

---

## روش‌های انتقال

دو روش اصلی برای انتقال پروژه وجود دارد:

### روش ۱: استفاده از Checkpoint (پیشنهادی)

این روش ساده‌ترین و سریع‌ترین روش است که توسط Manus پشتیبانی می‌شود. در این روش کدها به صورت خودکار منتقل می‌شوند، اما دیتابیس باید به صورت دستی export و import شود.

**مزایا:**
- سریع و آسان
- کدها به صورت خودکار منتقل می‌شوند
- Checkpoints حفظ می‌شوند
- خطای انسانی کمتر

**معایب:**
- دیتابیس باید به صورت دستی منتقل شود
- نیاز به دسترسی به هر دو اکانت

### روش ۲: Export و Import دستی

در این روش تمام اجزا به صورت دستی export و import می‌شوند.

**مزایا:**
- کنترل کامل بر فرآیند
- امکان بررسی و ویرایش قبل از import
- مستقل از پلتفرم Manus

**معایب:**
- زمان‌بر
- احتمال خطای انسانی بیشتر
- نیاز به دانش فنی بیشتر

---

## فرآیند انتقال (روش ۱: استفاده از Checkpoint)

### مرحله ۱: آماده‌سازی در اکانت قدیم

#### ۱.۱ ساخت Checkpoint نهایی

قبل از انتقال، یک checkpoint نهایی بسازید تا آخرین وضعیت پروژه ذخیره شود.

**مراحل:**
1. وارد پروژه در اکانت قدیم شوید
2. از منوی Management UI، گزینه "Save Checkpoint" را انتخاب کنید
3. یک توضیح مناسب بنویسید (مثلاً "Final checkpoint before migration")
4. منتظر بمانید تا checkpoint ساخته شود
5. شناسه checkpoint (version ID) را یادداشت کنید

#### ۱.۲ Export دیتابیس

دیتابیس باید به صورت دستی export شود زیرا checkpoint فقط کدها را منتقل می‌کند.

**روش A: استفاده از Management UI (پیشنهادی)**

1. وارد Management UI شوید
2. به بخش "Database" بروید
3. از منوی تنظیمات (⚙️)، گزینه "Export All Data" را انتخاب کنید
4. فایل SQL را دانلود کنید

**روش B: استفاده از Command Line**

اگر Management UI دسترسی export ندارد، از دستور زیر استفاده کنید:

```bash
# Export تمام جداول به فایل SQL
mysqldump -h <HOST> -u <USER> -p<PASSWORD> <DATABASE_NAME> > backup.sql

# یا استفاده از script Python
python3 << 'EOF'
import os
import subprocess

# اطلاعات اتصال از environment variable
db_url = os.getenv('DATABASE_URL')
# Parse connection string
# mysql://user:password@host:port/database

output_file = 'database_backup.sql'
subprocess.run(['mysqldump', '--all-databases', '--result-file', output_file])
print(f'Database exported to {output_file}')
EOF
```

#### ۱.۳ Export تنظیمات (Settings)

تنظیمات در جدول `settings` ذخیره شده‌اند، اما برای اطمینان بیشتر، آن‌ها را به صورت جداگانه export کنید.

**مراحل:**

1. وارد صفحه Settings شوید
2. تمام مقادیر را یادداشت کنید یا screenshot بگیرید
3. یا از دستور SQL زیر استفاده کنید:

```sql
SELECT * FROM settings;
```

4. خروجی را در فایل JSON ذخیره کنید

#### ۱.۴ Export لیست توییت‌های مهم

اگر توییت‌های خاصی دارید که می‌خواهید حتماً منتقل شوند:

```sql
-- Export bookmarks
SELECT * FROM bookmarks;

-- Export saved tweets
SELECT * FROM savedTweets;

-- Export scheduled posts
SELECT * FROM scheduledPosts;
```

### مرحله ۲: ایجاد پروژه در اکانت جدید

#### ۲.۱ ساخت پروژه جدید از Checkpoint

**مراحل:**

1. وارد اکانت Manus جدید شوید
2. از منوی اصلی، "New Project" را انتخاب کنید
3. گزینه "Import from Checkpoint" را انتخاب کنید
4. شناسه checkpoint (version ID) را وارد کنید
5. نام پروژه جدید را وارد کنید
6. "Create Project" را کلیک کنید
7. منتظر بمانید تا پروژه ساخته شود

**نکته:** اگر checkpoint از اکانت دیگری است، ممکن است نیاز به اشتراک‌گذاری checkpoint باشد. در این صورت:
- در اکانت قدیم، checkpoint را "Public" کنید
- لینک اشتراک‌گذاری را کپی کنید
- در اکانت جدید، از لینک برای import استفاده کنید

#### ۲.۲ Import دیتابیس

بعد از ساخت پروژه، دیتابیس را import کنید.

**روش A: استفاده از Management UI**

1. وارد Management UI شوید
2. به بخش "Database" بروید
3. از منوی تنظیمات (⚙️)، گزینه "Import Data" را انتخاب کنید
4. فایل SQL backup را آپلود کنید
5. منتظر بمانید تا import تکمیل شود

**روش B: استفاده از Command Line**

```bash
# Import از فایل SQL
mysql -h <HOST> -u <USER> -p<PASSWORD> <DATABASE_NAME> < backup.sql
```

**روش C: استفاده از Script (پیشنهادی برای دیتای زیاد)**

```javascript
// import-database.mjs
import { drizzle } from 'drizzle-orm/mysql2';
import fs from 'fs';

const db = drizzle(process.env.DATABASE_URL);

// خواندن فایل SQL
const sqlContent = fs.readFileSync('backup.sql', 'utf8');

// اجرای دستورات SQL
const statements = sqlContent.split(';').filter(s => s.trim());

for (const statement of statements) {
  if (statement.trim()) {
    await db.execute(statement);
  }
}

console.log('Database imported successfully');
```

اجرا:
```bash
node import-database.mjs
```

#### ۲.۳ تنظیم Environment Variables

متغیرهای محیطی سیستمی به صورت خودکار توسط Manus تنظیم می‌شوند. فقط بررسی کنید که درست هستند:

1. وارد Settings → Secrets شوید
2. بررسی کنید که تمام متغیرهای زیر وجود دارند:
   - `DATABASE_URL`
   - `JWT_SECRET`
   - `VITE_APP_ID`
   - و بقیه...

#### ۲.۴ تنظیم مجدد Settings

تنظیمات برنامه باید دوباره وارد شوند (اگر در import دیتابیس منتقل نشده‌اند):

1. وارد صفحه Settings شوید
2. تمام مقادیر را از یادداشت یا screenshot قبلی وارد کنید:
   - Apify Token
   - Telegram Bot Token
   - Telegram Chat ID
   - OpenRouter API Key
   - AI Model
   - AI Rewrite Prompt
   - و بقیه...
3. "Save Settings" را کلیک کنید

#### ۲.۵ تنظیم مجدد Telegram Bot

Webhook تلگرام باید دوباره تنظیم شود:

1. وارد صفحه Settings شوید
2. روی دکمه "🤖 Setup Telegram Mini App" کلیک کنید
3. منتظر پیام موفقیت بمانید
4. به ربات تلگرام بروید و `/start` بفرستید
5. بررسی کنید که ربات پاسخ می‌دهد

### مرحله ۳: تست و راه‌اندازی

#### ۳.۱ تست اتصال دیتابیس

```sql
-- بررسی تعداد رکوردها
SELECT COUNT(*) FROM users;
SELECT COUNT(*) FROM tweets;
SELECT COUNT(*) FROM bookmarks;
SELECT COUNT(*) FROM settings;
```

مقایسه کنید که تعداد رکوردها با اکانت قدیم یکسان است.

#### ۳.۲ تست عملکرد برنامه

**تست Dashboard:**
1. وارد Dashboard شوید
2. بررسی کنید که تمام صفحات بدون خطا باز می‌شوند
3. بررسی کنید که data ها نمایش داده می‌شوند

**تست Fetch:**
1. به صفحه "AI Twitter Monitor" بروید
2. روی "Fetch Now" کلیک کنید
3. بررسی کنید که توییت‌های جدید fetch می‌شوند

**تست Telegram Bot:**
1. به ربات تلگرام بروید
2. یک لینک Twitter بفرستید
3. بررسی کنید که ربات پاسخ می‌دهد و توییت را rewrite می‌کند

**تست Bookmarks:**
1. یک توییت را bookmark کنید
2. به صفحه Bookmarks بروید
3. بررسی کنید که توییت نمایش داده می‌شود

**تست Scheduled Posts:**
1. یک post زمان‌بندی شده ایجاد کنید
2. به صفحه Scheduled بروید
3. بررسی کنید که post نمایش داده می‌شود

#### ۳.۳ تست Schedule

اگر schedule خودکار دارید، بررسی کنید که درست کار می‌کند:

1. به صفحه Settings بروید
2. بررسی کنید که Schedule Time و Timezone درست تنظیم شده‌اند
3. منتظر بمانید تا زمان schedule برسد
4. بررسی کنید که fetch خودکار اجرا می‌شود

---

## فرآیند انتقال (روش ۲: Export و Import دستی)

### مرحله ۱: Export از اکانت قدیم

#### ۱.۱ دانلود تمام کدها

**روش A: استفاده از Management UI**

1. وارد Management UI شوید
2. به بخش "Code" بروید
3. روی دکمه "Download All Files" کلیک کنید
4. فایل ZIP را دانلود کنید

**روش B: استفاده از Git (اگر repository دارید)**

```bash
git clone <REPOSITORY_URL>
cd <PROJECT_NAME>
```

#### ۱.۲ Export دیتابیس

همان روش مرحله ۱.۲ در روش ۱

#### ۱.۳ Export تنظیمات

همان روش مرحله ۱.۳ در روش ۱

### مرحله ۲: ایجاد پروژه در اکانت جدید

#### ۲.۱ ساخت پروژه خالی

1. وارد اکانت Manus جدید شوید
2. از منوی اصلی، "New Project" را انتخاب کنید
3. Template مشابه با پروژه قدیم را انتخاب کنید (web-db-user)
4. نام پروژه را وارد کنید
5. "Create Project" را کلیک کنید

#### ۲.۲ آپلود کدها

**روش A: استفاده از Management UI**

1. وارد Management UI شوید
2. به بخش "Code" بروید
3. فایل‌های ZIP شده را آپلود کنید

**روش B: استفاده از Git**

```bash
# در دایرکتوری پروژه جدید
git init
git remote add origin <NEW_REPOSITORY_URL>
git add .
git commit -m "Initial commit from migration"
git push -u origin main
```

#### ۲.۳ Import دیتابیس

همان روش مرحله ۲.۲ در روش ۱

#### ۲.۴ تنظیم Environment Variables

همان روش مرحله ۲.۳ در روش ۱

#### ۲.۵ تنظیم مجدد Settings

همان روش مرحله ۲.۴ در روش ۱

#### ۲.۶ نصب Dependencies

```bash
pnpm install
```

#### ۲.۷ اجرای Migration

```bash
pnpm db:push
```

#### ۲.۸ راه‌اندازی سرور

```bash
pnpm dev
```

### مرحله ۳: تست و راه‌اندازی

همان روش مرحله ۳ در روش ۱

---

## Checklist انتقال

برای اطمینان از انتقال کامل، این checklist را بررسی کنید:

### قبل از انتقال

- [ ] Checkpoint نهایی ساخته شد
- [ ] دیتابیس export شد
- [ ] تنظیمات یادداشت شدند
- [ ] لیست API keys و tokens آماده است
- [ ] Screenshot از تمام صفحات گرفته شد

### در حین انتقال

- [ ] پروژه جدید ساخته شد
- [ ] کدها منتقل شدند
- [ ] دیتابیس import شد
- [ ] Environment variables تنظیم شدند
- [ ] Settings وارد شدند
- [ ] Telegram bot تنظیم شد

### بعد از انتقال

- [ ] اتصال دیتابیس تست شد
- [ ] تعداد رکوردها مطابقت دارد
- [ ] Dashboard بدون خطا کار می‌کند
- [ ] Fetch کار می‌کند
- [ ] Telegram bot پاسخ می‌دهد
- [ ] Bookmarks کار می‌کند
- [ ] Scheduled posts کار می‌کند
- [ ] Schedule خودکار کار می‌کند

---

## مشکلات رایج و راه‌حل

### مشکل ۱: دیتابیس import نمی‌شود

**علت:** فرمت فایل SQL اشتباه است یا حجم خیلی زیاد است.

**راه‌حل:**
1. فایل SQL را باز کنید و بررسی کنید که فرمت درست است
2. اگر حجم زیاد است، فایل را به چند بخش تقسیم کنید
3. از script Python/Node.js برای import استفاده کنید

### مشکل ۲: Telegram bot پاسخ نمی‌دهد

**علت:** Webhook تنظیم نشده است.

**راه‌حل:**
1. به صفحه Settings بروید
2. روی "Setup Telegram Mini App" کلیک کنید
3. بررسی کنید که Bot Token درست است

### مشکل ۳: Settings خالی است

**علت:** جدول settings در import دیتابیس منتقل نشده است.

**راه‌حل:**
1. فایل SQL backup را باز کنید
2. بخش مربوط به جدول settings را پیدا کنید
3. آن را به صورت دستی import کنید
4. یا تنظیمات را دوباره وارد کنید

### مشکل ۴: Environment variables درست نیست

**علت:** متغیرهای محیطی به صورت خودکار تنظیم نشده‌اند.

**راه‌حل:**
1. به Settings → Secrets بروید
2. بررسی کنید که تمام متغیرها وجود دارند
3. اگر نیست، با پشتیبانی Manus تماس بگیرید

### مشکل ۵: Fetch کار نمی‌کند

**علت:** Apify Token یا API keys درست تنظیم نشده‌اند.

**راه‌حل:**
1. به صفحه Settings بروید
2. بررسی کنید که Apify Token درست است
3. یک fetch تست کنید

---

## نکات امنیتی

### محافظت از API Keys

هنگام انتقال، مراقب باشید که API keys و tokens افشا نشوند:

1. هرگز API keys را در فایل‌های عمومی قرار ندهید
2. از environment variables استفاده کنید
3. بعد از انتقال، API keys قدیمی را revoke کنید (اختیاری)

### محافظت از دیتابیس

فایل backup دیتابیس حاوی اطلاعات حساس است:

1. فایل را رمزگذاری کنید
2. بعد از import، فایل را حذف کنید
3. از اتصال امن (SSL) برای دیتابیس استفاده کنید

---

## پشتیبانی و کمک

اگر در هر مرحله‌ای به مشکل برخوردید:

1. **داکیومنت Manus:** https://docs.manus.im
2. **پشتیبانی Manus:** https://help.manus.im
3. **Community Forum:** https://community.manus.im

---

## نتیجه‌گیری

با دنبال کردن این راهنما، می‌توانید پروژه AI Twitter Monitor را به صورت کامل و بدون از دست دادن هیچ داده‌ای به اکانت Manus جدید منتقل کنید. روش ۱ (استفاده از Checkpoint) برای اکثر موارد پیشنهاد می‌شود زیرا سریع‌تر و آسان‌تر است. اگر نیاز به کنترل بیشتر دارید، از روش ۲ استفاده کنید.

پس از انتقال، حتماً تمام قسمت‌های برنامه را تست کنید تا مطمئن شوید که همه چیز درست کار می‌کند.
